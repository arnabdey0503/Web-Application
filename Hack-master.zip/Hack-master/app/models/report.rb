class Report < ActiveRecord::Base
  belongs_to :child
end
